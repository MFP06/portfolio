<?php

// La page chat utilise les fonctions communes pour la session, la presence, les messages et les notifications.
require __DIR__ . '/functions.php';

// app_boot() demarre la session PHP, lit config.php et prepare les fichiers JSON si besoin.
$config = app_boot();

// Le chat est reserve aux utilisateurs connectes.
// Si aucun identifiant n'est trouve en session, require_login() renvoie vers la page de connexion.
$userIdentifier = require_login();

// On indique que l'utilisateur est actuellement actif.
// Cette ligne permet aux autres utilisateurs de le voir dans la liste "En ligne".
mark_user_online($config, $userIdentifier);

// Action envoyee par les formulaires du chat.
// Ici on lit seulement $_POST car les actions du chat viennent des formulaires, pas de l'URL.
$action = $_POST['action'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'create_conversation') {
    // Cree une conversation avec les utilisateurs selectionnes dans les checkbox users[].
    create_conversation($config, $userIdentifier);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'send_message') {
    // Ajoute un message dans la conversation selectionnee grace au champ cache conversation_id.
    send_chat_message($config, $userIdentifier);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'delete_conversation') {
    // Supprime une conversation et ses messages si l'utilisateur courant fait partie de cette conversation.
    delete_conversation($config, $userIdentifier);
}

// A partir d'ici, on prepare les donnees utilisees plus bas dans le HTML du chat.
$onlineUsers = load_online_users($config);

// On retire l'utilisateur actuel de la liste, car il ne va pas creer une conversation avec lui-meme.
unset($onlineUsers[$userIdentifier]);

// On recupere uniquement les conversations ou l'utilisateur courant est membre.
$conversations = user_conversations($config, $userIdentifier);

// Total de messages non lus, utilise pour le badge rouge dans le bouton Chat.
$unreadMessages = unread_count_total($config, $userIdentifier);

// L'URL peut contenir ?conversation=ID pour ouvrir une conversation precise.
$selectedId = $_GET['conversation'] ?? '';

// On cherche dans les conversations de l'utilisateur celle qui correspond a l'ID demande.
$selectedConversation = find_conversation($conversations, $selectedId);

if ($selectedConversation !== null && $selectedId !== '') {
    // Si l'utilisateur ouvre une conversation precise, on la marque comme lue.
    mark_conversation_as_read($config, $selectedConversation['id'], $userIdentifier);

    // On recharge les conversations pour mettre a jour les badges apres le passage en "lu".
    $conversations = user_conversations($config, $userIdentifier);

    // On recharge la conversation selectionnee apres la mise a jour.
    $selectedConversation = find_conversation($conversations, $selectedConversation['id']);
}

// Recupere un message temporaire, par exemple "Conversation creee" ou "Conversation supprimee".
$flash = pop_flash();

?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chat intranet</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="chat-body">
    <header class="topbar">
        <a class="brand" href="index.php">
            <img src="<?= e($config['logo_path']) ?>" alt="Logo">
            <span>Intranet</span>
        </a>
        <nav class="top-actions">
            <span class="user-pill"><?= e($userIdentifier) ?></span>
            <a class="nav-button" href="index.php">Accueil</a>
            <?php if (is_admin_ip($config['admin_ips'])): ?>
                <a class="nav-button" href="admin.php">Administration</a>
            <?php endif; ?>
            <a class="nav-button chat-button" href="chat.php">
                Chat
                <?php if ($unreadMessages > 0): ?>
                    <span class="unread-badge"><?= $unreadMessages > 9 ? '9+' : e((string)$unreadMessages) ?></span>
                <?php endif; ?>
            </a>
            <a class="nav-button logout" href="index.php?action=logout">Se deconnecter</a>
        </nav>
    </header>

    <main class="page chat-page">
        <?php if ($flash): ?>
            <p class="flash flash-main"><?= e($flash) ?></p>
        <?php endif; ?>

        <section class="chat-layout">
            <aside class="section chat-side">
                <div class="section-head">
                    <div>
                        <p class="eyebrow">En ligne</p>
                        <h2>Utilisateurs</h2>
                    </div>
                </div>

                <form method="post" class="chat-users-form">
                    <!-- Champ cache qui indique a PHP que l'on veut creer une conversation. -->
                    <input type="hidden" name="action" value="create_conversation">

                    <?php if (empty($onlineUsers)): ?>
                        <p class="empty">Aucun autre utilisateur connecte.</p>
                    <?php endif; ?>

                    <?php foreach ($onlineUsers as $name => $lastSeen): ?>
                        <!-- Utilisateur actuellement connecte que l'on peut cocher. -->
                        <label class="online-user">
                            <!-- Le name users[] permet d'envoyer plusieurs utilisateurs en meme temps. -->
                            <input type="checkbox" name="users[]" value="<?= e($name) ?>">
                            <span class="online-dot"></span>
                            <span><?= e($name) ?></span>
                            <small>connecte</small>
                        </label>
                    <?php endforeach; ?>

                    <button type="submit">Nouvelle conversation</button>
                </form>

                <div class="chat-conversations">
                    <p class="eyebrow">Conversations</p>
                    <?php if (empty($conversations)): ?>
                        <p class="empty">Aucune conversation.</p>
                    <?php endif; ?>

                    <?php foreach ($conversations as $conversation): ?>
                        <?php
                        // Titre de la conversation : on affiche les autres membres, pas soi-meme.
                        $conversationNames = [];
                        foreach ($conversation['members'] ?? [] as $member) {
                            if ($member !== $userIdentifier) {
                                $conversationNames[] = $member;
                            }
                        }
                        $conversationTitle = $conversationNames ? implode(', ', $conversationNames) : 'Conversation';

                        // $isActive ajoute la classe active sur la conversation ouverte.
                        $isActive = $selectedConversation && $conversation['id'] === $selectedConversation['id'];

                        // $unread contient le nombre de messages non lus dans cette conversation.
                        $unread = unread_count_for_conversation($conversation, $userIdentifier);
                        ?>

                        <div class="conversation-row">
                            <!-- Lien qui ouvre cette conversation. -->
                            <a class="conversation-link <?= $isActive ? 'active' : '' ?>" href="chat.php?conversation=<?= e($conversation['id']) ?>">
                                <span><?= e($conversationTitle) ?></span>
                                <!-- Badge rouge si messages non lus. -->
                                <?php if ($unread > 0): ?>
                                    <span class="unread-badge"><?= $unread > 9 ? '9+' : e((string)$unread) ?></span>
                                <?php endif; ?>
                            </a>
                            <form method="post" class="conversation-delete">
                                <!-- Formulaire pour supprimer toute la conversation. -->
                                <input type="hidden" name="action" value="delete_conversation">
                                <input type="hidden" name="conversation_id" value="<?= e($conversation['id']) ?>">
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            </aside>

            <section class="section chat-main">
                <?php if ($selectedConversation === null): ?>
                    <div class="chat-empty">
                        <p class="eyebrow">Chat</p>
                        <h2>Aucune conversation selectionnee</h2>
                        <p>Selectionnez des utilisateurs en ligne pour commencer.</p>
                    </div>
                <?php else: ?>
                    <?php
                    // Titre de la conversation ouverte.
                    $selectedNames = [];
                    foreach ($selectedConversation['members'] ?? [] as $member) {
                        if ($member !== $userIdentifier) {
                            $selectedNames[] = $member;
                        }
                    }
                    $selectedTitle = $selectedNames ? implode(', ', $selectedNames) : 'Conversation';
                    ?>

                    <div class="section-head">
                        <div>
                            <p class="eyebrow">Conversation</p>
                            <h2><?= e($selectedTitle) ?></h2>
                        </div>
                    </div>

                    <div class="messages">
                        <?php if (empty($selectedConversation['messages'])): ?>
                            <p class="empty">Aucun message pour le moment.</p>
                        <?php endif; ?>

                        <?php foreach ($selectedConversation['messages'] as $message): ?>
                            <!-- Message affiche a gauche ou a droite selon l'auteur. -->
                            <?php $mine = ($message['author'] ?? '') === $userIdentifier; ?>
                            <article class="message <?= $mine ? 'mine' : '' ?>">
                                <div>
                                    <strong><?= e($message['author'] ?? '') ?></strong>
                                    <small><?= e($message['created_at'] ?? '') ?></small>
                                </div>
                                <p><?= nl2br(e($message['text'] ?? '')) ?></p>
                            </article>
                        <?php endforeach; ?>
                    </div>

                    <form method="post" class="message-form">
                        <!-- Champ cache qui dit a PHP que l'on envoie un message. -->
                        <input type="hidden" name="action" value="send_message">
                        <!-- Champ cache avec la conversation dans laquelle envoyer le message. -->
                        <input type="hidden" name="conversation_id" value="<?= e($selectedConversation['id']) ?>">
                        <textarea name="message" rows="3" required placeholder="Ecrire un message"></textarea>
                        <button type="submit">Envoyer</button>
                    </form>
                <?php endif; ?>
            </section>
        </section>
    </main>

    <?= render_browser_notifications_script($config, $userIdentifier) ?>

    <script>
        // Ping regulier pour garder l'utilisateur en ligne.
        setInterval(function () {
            fetch('presence.php', { cache: 'no-store' });
        }, 10000);

        // Recharge le chat pour recevoir les nouveaux messages.
        setInterval(function () {
            var active = document.activeElement;
            var isWriting = active && (active.tagName === 'TEXTAREA' || active.tagName === 'INPUT');

            // Ne recharge pas si l'utilisateur ecrit un message.
            if (!isWriting) {
                window.location.reload();
            }
        }, 5000);

        // Zone scrollable des messages.
        var messages = document.querySelector('.messages');

        // Indique si on arrive ici apres avoir clique sur une notification.
        // Si oui, on descend automatiquement en bas pour voir le nouveau message.
        var fromNotification = new URLSearchParams(window.location.search).get('from_notification') === '1';

        // Champ cache qui contient l'id de la conversation ouverte.
        var conversationInput = document.querySelector('input[name="conversation_id"]');

        // Cle localStorage differente pour chaque conversation.
        // Comme ca, chaque conversation garde sa propre position de scroll.
        var scrollKey = conversationInput ? 'chatScroll_' + conversationInput.value : 'chatScroll_default';

        if (messages) {
            // Recupere l'ancienne position de scroll si elle existe.
            var savedScroll = localStorage.getItem(scrollKey);

            if (fromNotification) {
                // Depuis une notification, on veut voir directement le nouveau message.
                messages.scrollTop = messages.scrollHeight;

                // On sauvegarde aussi cette nouvelle position en bas.
                localStorage.setItem(scrollKey, messages.scrollTop);
            } else if (savedScroll !== null) {
                // Replace l'utilisateur ou il etait avant le rechargement.
                messages.scrollTop = parseInt(savedScroll, 10);
            } else {
                // Sinon descend directement au dernier message.
                messages.scrollTop = messages.scrollHeight;
            }

            // A chaque scroll, sauvegarde la position.
            messages.addEventListener('scroll', function () {
                localStorage.setItem(scrollKey, messages.scrollTop);
            });
        }
    </script>
</body>
</html>
