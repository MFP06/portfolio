<?php

/*
    Fichier avec toutes les fonctions communes.
*/

function app_boot()
{
    // Ouvre ou reprend la session PHP de l'utilisateur.
    // La session sert a retenir l'identifiant entre deux pages sans redemander la connexion.
    session_start();

    // Charge les reglages du site depuis config.php.
    // On y retrouve par exemple les IP admin, le chemin du logo et les fichiers JSON.
    $config = require __DIR__ . '/config.php';

    // Verifie que les dossiers/fichiers utiles existent.
    // Cela evite une erreur si storage/data ou les fichiers JSON n'ont pas encore ete crees.
    prepare_folders($config);

    // Renvoie la configuration pour les autres fichiers.
    return $config;
}

function prepare_folders($config)
{
    // Liste des dossiers que l'application doit avoir pour fonctionner.
    // data_dir contient les JSON, files_root contient les fichiers telechargeables,
    // announcement_images_root contient les images ajoutees aux annonces.
    $folders = [
        $config['data_dir'],
        $config['files_root'],
        $config['announcement_images_root'],
    ];

    // Cree les dossiers manquants.
    // Le true a la fin permet aussi de creer les dossiers parents si besoin.
    foreach ($folders as $folder) {
        if (!is_dir($folder)) {
            mkdir($folder, 0775, true);
        }
    }

    // Cree le fichier des annonces si besoin.
    if (!file_exists(announcements_file($config))) {
        file_put_contents(announcements_file($config), '[]');
    }

    // Cree le fichier du chat si besoin.
    if (!file_exists($config['chat_file'])) {
        file_put_contents($config['chat_file'], '[]');
    }

    // Cree le fichier de logs des messages si besoin.
    // Ce fichier est separe du chat principal : supprimer une conversation ne supprime pas l'historique de logs.
    if (!file_exists($config['chat_log_file'])) {
        file_put_contents($config['chat_log_file'], '');
    }

    // Cree le fichier des utilisateurs connectes si besoin.
    if (!file_exists($config['online_file'])) {
        file_put_contents($config['online_file'], '[]');
    }
}

function current_user_identifier()
{
    // Si un identifiant est en session, l'utilisateur est connecte.
    // Cette session appartient au navigateur courant, pas a tous les utilisateurs du site.
    if (!empty($_SESSION['user_identifier'])) {
        return $_SESSION['user_identifier'];
    }

    // Sinon personne n'est connecte.
    return null;
}

function require_login()
{
    // Recupere l'identifiant courant avec la fonction juste au-dessus.
    $identifier = current_user_identifier();

    // Si aucun identifiant n'est trouve, la personne n'a pas le droit de rester sur cette page.
    // On la renvoie donc directement vers index.php.
    if ($identifier === null) {
        redirect('index.php');
    }

    // Sinon on renvoie l'identifiant.
    return $identifier;
}

function mark_user_online($config, $identifier)
{
    // Charge tous les utilisateurs connus, meme ceux qui ne sont plus recents.
    // On fait ca pour ne pas effacer les autres noms en reecrivant le fichier JSON.
    $users = load_online_users($config, false);

    // Met a jour l'heure de derniere activite avec time().
    // time() donne un nombre de secondes, pratique pour savoir depuis combien de temps la personne est inactive.
    $users[$identifier] = time();

    // Sauvegarde la liste.
    save_online_users($config, $users);
}

function load_online_users($config, $onlyRecent = true)
{
    // Lit le fichier JSON des utilisateurs connectes.
    // Ce fichier contient les identifiants et leur derniere date d'activite.
    $json = file_get_contents($config['online_file']);

    // Transforme le JSON en tableau PHP.
    $users = json_decode($json ?: '[]', true);

    // Si le fichier est vide/corrompu, on repart sur un tableau vide.
    if (!is_array($users)) {
        return [];
    }

    // Si on demande tout le monde, on renvoie sans filtrer.
    // C'est utile quand on veut modifier le fichier sans supprimer d'anciens utilisateurs tout de suite.
    if (!$onlyRecent) {
        return $users;
    }

    // Liste qui contiendra uniquement les utilisateurs vus recemment.
    $recentUsers = [];

    // Parcourt chaque utilisateur avec son timestamp de derniere activite.
    // Si l'utilisateur n'a pas donne signe de vie depuis trop longtemps, il disparait de la liste "connecte".
    foreach ($users as $name => $lastSeen) {
        // 35 secondes sans activite = considere deconnecte.
        if (time() - (int)$lastSeen <= 35) {
            $recentUsers[$name] = $lastSeen;
        }
    }

    // On sauvegarde la liste nettoyee.
    save_online_users($config, $recentUsers);

    // On renvoie uniquement les utilisateurs actuellement connectes.
    return $recentUsers;
}

function save_online_users($config, $users)
{
    // Sauvegarde la presence des utilisateurs dans online-users.json.
    file_put_contents($config['online_file'], json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function is_admin_ip($adminIps)
{
    // Recupere l'IP du visiteur.
    // Ensuite on compare cette IP avec la liste admin_ips dans config.php.
    $visitorIp = get_visitor_ip();

    // Verifie si l'IP est directement autorisee.
    if (in_array($visitorIp, $adminIps, true)) {
        return true;
    }

    // En local, Wamp peut voir localhost comme 127.0.0.1 ou comme ::1.
    if ($visitorIp === '127.0.0.1' && in_array('::1', $adminIps, true)) {
        return true;
    }

    if ($visitorIp === '::1' && in_array('127.0.0.1', $adminIps, true)) {
        return true;
    }

    return false;
}

function require_admin($config)
{
    // Il faut deja etre connecte pour acceder a l'administration.
    // Donc meme avec une bonne IP, une personne non connectee retourne d'abord a la connexion.
    require_login();

    // Si l'IP n'est pas admin, on bloque.
    // La suite affiche une page d'erreur simple au lieu de laisser acceder a admin.php.
    if (!is_admin_ip($config['admin_ips'])) {
        // Code HTTP 403 = acces interdit.
        http_response_code(403);

        ?>
        <!doctype html>
        <html lang="fr">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Acces refuse</title>
            <link rel="stylesheet" href="style.css">
        </head>
        <body>
            <main class="page">
                <section class="section">
                    <p class="eyebrow">Administration</p>
                    <h2>Accés refusé</h2>
                    <p>Tout accès ou tentatives de connexions non authorisées sont prohibées.</p>
                    <a class="nav-button" href="index.php">Retour accueil</a>
                </section>
            </main>
        </body>
        </html>
        <?php
        exit;
    }
}

function get_visitor_ip()
{
    // REMOTE_ADDR est l'adresse IP vue par Apache/Wamp pour cette requete.
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';

    // Certains serveurs notent localhost comme ::ffff:127.0.0.1.
    if (strpos($ip, '::ffff:') === 0) {
        $ip = substr($ip, 7);
    }

    return $ip;
}

function handle_login()
{
    // Recupere la config car cette fonction peut etre appelee avant le reste de la page.
    // On en a besoin pour lire le fichier des utilisateurs connectes.
    $config = require __DIR__ . '/config.php';

    // Recupere l'identifiant envoye par le formulaire.
    // trim() retire les espaces au debut et a la fin pour eviter un identifiant " matheo ".
    $identifier = trim($_POST['identifier'] ?? '');

    // Verifie la longueur minimum.
    if (strlen($identifier) < 6) {
        $_SESSION['flash'] = 'Veuillez saisir un identifiant de 6 caracteres minimum.';
        redirect('index.php');
    }

    // Verifie que cet identifiant n'est pas deja connecte.
    // load_online_users($config) renvoie seulement les utilisateurs actifs recemment.
    $onlineUsers = load_online_users($config);
    // Si le nom existe dans la liste recente, il est deja utilise.
    if (isset($onlineUsers[$identifier])) {
        $_SESSION['flash'] = 'Cet identifiant est deja connecte.';
        redirect('index.php');
    }

    // Enregistre l'identifiant en session.
    // substr limite la taille pour eviter un nom trop long dans le menu et les fichiers JSON.
    $_SESSION['user_identifier'] = substr($identifier, 0, 80);

    // Marque directement l'utilisateur comme connecte.
    mark_user_online($config, $_SESSION['user_identifier']);

    // Redirige vers l'accueil.
    redirect('index.php');
}

function logout()
{
    // Recharge la config pour acceder aux fichiers JSON.
    $config = require __DIR__ . '/config.php';

    // Recupere l'utilisateur actuel.
    $identifier = current_user_identifier();

    if ($identifier !== null) {
        // Retire l'utilisateur de la liste des connectes.
        mark_user_offline($config, $identifier);

        // Supprime ses conversations pour repartir proprement.
        delete_user_chat_data($config, $identifier);
    }

    // Ferme la session PHP.
    session_destroy();

    // Retour a la page de connexion.
    redirect('index.php');
}

function mark_user_offline($config, $identifier)
{
    // Charge tous les utilisateurs, meme les anciens.
    $users = load_online_users($config, false);

    // Supprime l'identifiant de la liste des connectes.
    unset($users[$identifier]);

    // Sauvegarde la liste modifiee.
    save_online_users($config, $users);
}

function delete_user_chat_data($config, $identifier)
{
    // Charge toutes les conversations.
    $chat = load_chat($config);

    // Nouvelle liste qui gardera seulement les conversations des autres.
    $newChat = [];

    // Parcourt toutes les conversations.
    foreach ($chat as $conversation) {
        // Si l'utilisateur deconnecte n'est pas membre, on garde la conversation.
        if (!in_array($identifier, $conversation['members'] ?? [], true)) {
            $newChat[] = $conversation;
        }
    }

    // Sauvegarde le chat nettoye.
    save_chat($config, $newChat);
}

function load_chat($config)
{
    // Lit le fichier JSON du chat.
    $json = file_get_contents($config['chat_file']);

    // Convertit le JSON en tableau PHP.
    $chat = json_decode($json ?: '[]', true);

    // Si le fichier n'est pas correct, on retourne un tableau vide.
    if (!is_array($chat)) {
        return [];
    }

    // Renvoie toutes les conversations.
    return $chat;
}

function save_chat($config, $chat)
{
    // Sauvegarde toutes les conversations dans chat.json.
    file_put_contents($config['chat_file'], json_encode($chat, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function log_chat_message($config, $conversationId, $messageData)
{
    // Prepare une entree de log independante du fichier chat.json.
    // On garde les informations utiles pour retrouver qui a ecrit quoi, quand, et dans quelle conversation.
    $logEntry = [
        'conversation_id' => $conversationId,
        'author' => $messageData['author'] ?? '',
        'text' => $messageData['text'] ?? '',
        'created_at' => $messageData['created_at'] ?? date('d-m-Y H:i'),
        'ip' => get_visitor_ip(),
    ];

    // JSONL = une ligne JSON par message.
    // FILE_APPEND ajoute a la fin, LOCK_EX evite deux ecritures simultanees dans le fichier de logs.
    file_put_contents(
        $config['chat_log_file'],
        json_encode($logEntry, JSON_UNESCAPED_UNICODE) . PHP_EOL,
        FILE_APPEND | LOCK_EX
    );
}

function create_conversation($config, $currentUser)
{
    // Recupere les utilisateurs coches dans le formulaire.
    $selectedUsers = $_POST['users'] ?? [];

    if (!is_array($selectedUsers)) {
        $selectedUsers = [];
    }

    // Ajoute l'utilisateur actuel dans la conversation.
    $members = [$currentUser];
    foreach ($selectedUsers as $user) {
        $user = trim($user);
        if ($user !== '' && $user !== $currentUser) {
            $members[] = $user;
        }
    }

    // Trie pour comparer facilement avec les conversations deja existantes.
    // Exemple : Alice+Bob et Bob+Alice doivent etre considerees comme la meme conversation.
    $members = array_values(array_unique($members));
    sort($members);

    if (count($members) < 2) {
        $_SESSION['flash'] = 'Choisissez au moins une personne.';
        redirect('chat.php');
    }

    // Charge les conversations existantes.
    $chat = load_chat($config);

    // Evite de creer une conversation en doublon avec les memes personnes.
    foreach ($chat as $conversation) {
        $existingMembers = $conversation['members'] ?? [];
        // Meme tri que plus haut pour eviter les doublons avec les memes personnes.
        sort($existingMembers);

        if ($existingMembers === $members) {
            redirect('chat.php?conversation=' . rawurlencode($conversation['id']));
        }
    }

    // Ajoute la nouvelle conversation.
    $chat[] = [
        'id' => bin2hex(random_bytes(8)),
        'members' => $members,
        'messages' => [],
        'read_at' => [
            $currentUser => time(),
        ],
        'created_at' => date('Y-m-d H:i'),
    ];

    // Sauvegarde puis redirige.
    save_chat($config, $chat);
    $_SESSION['flash'] = 'Conversation creee.';
    redirect('chat.php');
}

function send_chat_message($config, $currentUser)
{
    // Recupere la conversation et le message du formulaire.
    $conversationId = $_POST['conversation_id'] ?? '';
    $message = trim($_POST['message'] ?? '');

    if ($message === '') {
        redirect('chat.php?conversation=' . rawurlencode($conversationId));
    }

    // Charge tout le chat.
    $chat = load_chat($config);

    // Cherche la bonne conversation.
    foreach ($chat as $key => $conversation) {
        if (($conversation['id'] ?? '') === $conversationId && in_array($currentUser, $conversation['members'], true)) {
            // Prepare le message une seule fois pour le stocker dans le chat et dans les logs.
            $messageData = [
                'author' => $currentUser,
                // Limite a 1000 caracteres pour garder le fichier JSON raisonnable.
                'text' => substr($message, 0, 1000),
                'time' => time(),
                'created_at' => date('Y-m-d H:i'),
            ];

            // Ajoute le message a la conversation.
            $chat[$key]['messages'][] = $messageData;

            // Sauvegarde le chat.
            save_chat($config, $chat);

            // Sauvegarde une copie du message dans le fichier de logs separe.
            log_chat_message($config, $conversationId, $messageData);

            redirect('chat.php?conversation=' . rawurlencode($conversationId));
        }
    }

    redirect('chat.php');
}

function delete_conversation($config, $currentUser)
{
    // Conversation demandee par le bouton Supprimer.
    $conversationId = $_POST['conversation_id'] ?? '';

    // Charge toutes les conversations.
    $chat = load_chat($config);

    // Nouvelle liste sans la conversation supprimee.
    $newChat = [];

    // Parcourt toutes les conversations.
    foreach ($chat as $conversation) {
        // Verifie si c'est la conversation a supprimer.
        $isConversation = ($conversation['id'] ?? '') === $conversationId;

        // Verifie que l'utilisateur fait bien partie de cette conversation.
        $isMember = in_array($currentUser, $conversation['members'] ?? [], true);

        // On garde la conversation si ce n'est pas celle visee, ou si l'utilisateur n'a pas le droit.
        if (!$isConversation || !$isMember) {
            $newChat[] = $conversation;
        }
    }

    // Sauvegarde la liste nettoyee.
    save_chat($config, $newChat);

    // Message temporaire pour l'utilisateur.
    $_SESSION['flash'] = 'Conversation supprimee.';

    // Retour au chat.
    redirect('chat.php');
}

function user_conversations($config, $currentUser)
{
    // Charge toutes les conversations.
    $chat = load_chat($config);

    // Contiendra uniquement les conversations de cet utilisateur.
    $result = [];

    // Parcourt toutes les conversations.
    foreach ($chat as $conversation) {
        // On garde seulement celles ou l'utilisateur est membre.
        if (in_array($currentUser, $conversation['members'] ?? [], true)) {
            $result[] = $conversation;
        }
    }

    // Renvoie les conversations visibles par l'utilisateur.
    return $result;
}

function find_conversation($conversations, $id)
{
    // Cherche une conversation par son identifiant.
    foreach ($conversations as $conversation) {
        if (($conversation['id'] ?? '') === $id) {
            return $conversation;
        }
    }

    // Rien trouve.
    return null;
}

function unread_count_for_conversation($conversation, $currentUser)
{
    // Date du dernier passage de l'utilisateur dans cette conversation.
    $readAt = $conversation['read_at'][$currentUser] ?? 0;

    // Compteur de messages non lus.
    $count = 0;

    foreach ($conversation['messages'] ?? [] as $message) {
        $author = $message['author'] ?? '';
        $messageTime = $message['time'] ?? 0;

        // Compte seulement les messages des autres, envoyes apres la derniere lecture.
        if ($author !== $currentUser && $messageTime > $readAt) {
            $count++;
        }
    }

    return $count;
}

function unread_count_total($config, $currentUser)
{
    // Total general des messages non lus.
    $total = 0;

    // Recupere les conversations de l'utilisateur.
    $conversations = user_conversations($config, $currentUser);

    // Additionne les non lus de chaque conversation.
    foreach ($conversations as $conversation) {
        $total += unread_count_for_conversation($conversation, $currentUser);
    }

    // Renvoie le total pour le badge Chat.
    return $total;
}

function mark_conversation_as_read($config, $conversationId, $currentUser)
{
    // Si aucune conversation n'est selectionnee, on ne fait rien.
    if ($conversationId === '') {
        return;
    }

    // Charge toutes les conversations.
    $chat = load_chat($config);

    // Cherche la conversation a marquer comme lue.
    foreach ($chat as $key => $conversation) {
        if (($conversation['id'] ?? '') === $conversationId && in_array($currentUser, $conversation['members'] ?? [], true)) {
            // Cree le tableau read_at s'il n'existe pas encore.
            if (empty($chat[$key]['read_at']) || !is_array($chat[$key]['read_at'])) {
                $chat[$key]['read_at'] = [];
            }

            // Stocke l'heure de lecture pour cet utilisateur.
            $chat[$key]['read_at'][$currentUser] = time();

            // Sauvegarde la modification.
            save_chat($config, $chat);
            return;
        }
    }
}

function add_announcement($config)
{
    // Recupere le titre et le contenu depuis le formulaire.
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');

    // Refuse une annonce vide.
    if ($title === '' || $content === '') {
        $_SESSION['flash'] = 'Titre et contenu obligatoires.';
        redirect('admin.php');
    }

    // Charge les annonces existantes.
    $announcements = load_announcements($config);

    // Prepare la nouvelle annonce.
    $newAnnouncement = [
        'id' => bin2hex(random_bytes(8)),
        'title' => substr($title, 0, 120),
        'content' => substr($content, 0, 3000),
        'image' => save_announcement_image($config),
        'created_at' => date('Y-m-d H:i'),
    ];

    // Ajoute la nouvelle annonce au debut de la liste.
    array_unshift($announcements, $newAnnouncement);

    // Sauvegarde toutes les annonces.
    save_announcements($config, $announcements);

    // Message de confirmation.
    $_SESSION['flash'] = 'Annonce ajoutee.';

    // Retour admin.
    redirect('admin.php');
}

function delete_announcement($config)
{
    // ID de l'annonce a supprimer.
    $idToDelete = $_POST['id'] ?? '';

    // Charge les annonces existantes.
    $announcements = load_announcements($config);

    // Nouvelle liste sans l'annonce supprimee.
    $newList = [];

    // Parcourt toutes les annonces.
    foreach ($announcements as $announcement) {
        // Si c'est l'annonce visee, on supprime aussi son image.
        if (($announcement['id'] ?? '') === $idToDelete) {
            if (!empty($announcement['image'])) {
                delete_announcement_image($config, $announcement['image']);
            }
        } else {
            // Sinon on garde l'annonce.
            $newList[] = $announcement;
        }
    }

    // Sauvegarde la liste nettoyee.
    save_announcements($config, $newList);

    // Message de confirmation.
    $_SESSION['flash'] = 'Annonce supprimee.';

    // Retour admin.
    redirect('admin.php');
}

function upload_file($config)
{
    // Dossier cible demande dans le formulaire.
    $folder = clean_path($_POST['folder'] ?? '');

    // Refuse les chemins invalides comme ../
    if ($folder === null) {
        $_SESSION['flash'] = 'Dossier invalide.';
        redirect('admin.php');
    }

    // Verifie qu'un fichier est bien envoye.
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['flash'] = 'Fichier invalide ou trop volumineux.';
        redirect('admin.php');
    }

    // Chemin complet du dossier de destination.
    $destinationFolder = make_path($config['files_root'], $folder);

    // Cree le dossier si besoin.
    if (!is_dir($destinationFolder)) {
        mkdir($destinationFolder, 0775, true);
    }

    // Nettoie le nom du fichier.
    $fileName = clean_file_name($_FILES['file']['name']);

    // Refuse un nom vide/invalide.
    if ($fileName === '') {
        $_SESSION['flash'] = 'Nom de fichier invalide.';
        redirect('admin.php');
    }

    // Trouve un nom disponible si le fichier existe deja.
    $destinationFile = get_available_file_name($destinationFolder, $fileName);

    // Deplace le fichier envoye vers le stockage.
    move_uploaded_file($_FILES['file']['tmp_name'], $destinationFile);

    // Message de confirmation.
    $_SESSION['flash'] = 'Fichier ajoute.';

    // Retour admin.
    redirect('admin.php');
}

function delete_file($config)
{
    // Chemin relatif du fichier a supprimer.
    $relativePath = clean_path($_POST['path'] ?? '');

    // Chemin absolu du dossier racine des fichiers.
    $root = realpath($config['files_root']);

    // Chemin absolu du fichier vise.
    $file = $relativePath !== null ? realpath(make_path($config['files_root'], $relativePath)) : false;

    // Supprime uniquement si le fichier existe et reste dans le bon dossier.
    if ($root && $file && is_file($file) && is_in_folder($file, $root)) {
        unlink($file);
        remove_empty_folders(dirname($file), $root);
        $_SESSION['flash'] = 'Fichier supprime.';
    }

    redirect('admin.php');
}

function announcements_file($config)
{
    // Renvoie le chemin du fichier JSON des annonces.
    return $config['data_dir'] . '/announcements.json';
}

function load_announcements($config)
{
    // Lit le JSON des annonces.
    $json = file_get_contents(announcements_file($config));

    // Convertit le JSON en tableau PHP.
    $announcements = json_decode($json ?: '[]', true);

    // Si le fichier est incorrect, on evite l'erreur et on renvoie vide.
    if (!is_array($announcements)) {
        return [];
    }

    // Renvoie les annonces.
    return $announcements;
}

function save_announcements($config, $announcements)
{
    // Convertit les annonces en JSON lisible.
    $json = json_encode($announcements, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    // Ecrit le JSON dans le fichier.
    file_put_contents(announcements_file($config), $json);
}

function scan_files($folder, $relativePath = '')
{
    // Si le dossier n'existe pas, il n'y a rien a afficher.
    if (!is_dir($folder)) {
        return [];
    }

    // Liste les fichiers/dossiers presents.
    $items = scandir($folder);

    // Tableau final de l'arborescence.
    $tree = [];

    // Parcourt chaque element trouve.
    foreach ($items as $item) {
        // Ignore les elements techniques.
        if ($item === '.' || $item === '..' || $item === '.gitkeep') {
            continue;
        }

        // Chemin complet sur le disque.
        $fullPath = $folder . DIRECTORY_SEPARATOR . $item;

        // Chemin relatif utilise dans les liens et localStorage.
        $itemRelativePath = trim($relativePath . '/' . $item, '/');

        // Si c'est un dossier, on scanne son contenu.
        if (is_dir($fullPath)) {
            $children = scan_files($fullPath, $itemRelativePath);

            // On affiche seulement les dossiers qui contiennent quelque chose.
            if (!empty($children)) {
                $tree[] = [
                    'type' => 'dir',
                    'name' => $item,
                    'path' => $itemRelativePath,
                    'children' => $children,
                ];
            }
        } else {
            // Sinon c'est un fichier, on l'ajoute a la liste.
            $tree[] = [
                'type' => 'file',
                'name' => $item,
                'path' => $itemRelativePath,
                'size' => filesize($fullPath),
            ];
        }
    }

    // Renvoie toute l'arborescence.
    return $tree;
}

function render_file_tree($items, $showDeleteButton)
{
    // Debut de la liste HTML.
    $html = '<ul class="tree-list">';

    // Parcourt chaque element de l'arborescence.
    foreach ($items as $item) {
        // Affichage d'un dossier.
        if ($item['type'] === 'dir') {
            $html .= '<li class="tree-dir">';
            // data-tree-path sert au JavaScript pour rouvrir les dossiers apres un rechargement.
            $html .= '<details data-tree-path="' . e($item['path']) . '">';
            $html .= '<summary><span class="tree-twist"></span><span class="tree-icon folder"></span><span>' . e($item['name']) . '</span></summary>';
            // Appel recursif pour afficher les fichiers/dossiers dedans.
            $html .= render_file_tree($item['children'], $showDeleteButton);
            $html .= '</details>';
            $html .= '</li>';
        } else {
            // Affichage d'un fichier.
            $html .= '<li class="tree-file">';
            $html .= '<a href="index.php?action=download&file=' . rawurlencode($item['path']) . '">';
            $html .= '<span class="tree-spacer"></span><span class="tree-icon document"></span><span class="file-name">' . e($item['name']) . '</span>';
            $html .= '</a>';
            $html .= '<span class="file-size">' . e(format_size($item['size'])) . '</span>';

            // En admin, on ajoute le bouton supprimer.
            if ($showDeleteButton) {
                $html .= '<form method="post" class="inline-delete">';
                // Ces champs caches indiquent au PHP quel fichier supprimer.
                $html .= '<input type="hidden" name="action" value="delete_file">';
                $html .= '<input type="hidden" name="path" value="' . e($item['path']) . '">';
                $html .= '<button type="submit">Supprimer</button>';
                $html .= '</form>';
            }

            $html .= '</li>';
        }
    }

    // Fin de la liste HTML.
    $html .= '</ul>';

    // Renvoie le HTML construit.
    return $html;
}

function serve_download($config)
{
    // Recupere et nettoie le chemin demande dans l'URL.
    $relativePath = clean_path($_GET['file'] ?? '');

    // Chemin reel du dossier racine autorise.
    $root = realpath($config['files_root']);

    // Chemin reel du fichier demande.
    $file = $relativePath !== null ? realpath(make_path($config['files_root'], $relativePath)) : false;

    // Securite : refuse si le fichier n'existe pas ou sort du dossier autorise.
    if (!$root || !$file || !is_file($file) || !is_in_folder($file, $root)) {
        http_response_code(404);
        exit('Fichier introuvable.');
    }

    // Force le navigateur a telecharger le fichier.
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file) . '"');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}

function serve_announcement_image($config)
{
    // Recupere le nom de l'image dans l'URL.
    $imageName = clean_file_name($_GET['image'] ?? '');

    // Dossier racine des images d'annonces.
    $root = realpath($config['announcement_images_root']);

    // Chemin complet de l'image.
    $image = $imageName !== '' ? realpath(make_path($config['announcement_images_root'], $imageName)) : false;

    // Securite : l'image doit exister et rester dans le dossier autorise.
    if (!$root || !$image || !is_file($image) || !is_in_folder($image, $root)) {
        http_response_code(404);
        exit('Image introuvable.');
    }

    // Recupere l'extension pour choisir le bon Content-Type.
    $extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
    $type = 'application/octet-stream';

    if ($extension === 'jpg' || $extension === 'jpeg') {
        $type = 'image/jpeg';
    }
    if ($extension === 'png') {
        $type = 'image/png';
    }
    if ($extension === 'gif') {
        $type = 'image/gif';
    }
    if ($extension === 'webp') {
        $type = 'image/webp';
    }

    // Envoie l'image au navigateur.
    header('Content-Type: ' . $type);
    readfile($image);
    exit;
}

function save_announcement_image($config)
{
    // Si aucune image n'est envoyee, on ne stocke rien.
    if (empty($_FILES['announcement_image']) || $_FILES['announcement_image']['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    // Si l'upload a echoue, on ignore l'image.
    if ($_FILES['announcement_image']['error'] !== UPLOAD_ERR_OK) {
        return null;
    }

    // Nettoie le nom original.
    $oldName = clean_file_name($_FILES['announcement_image']['name']);

    // Recupere l'extension.
    $extension = strtolower(pathinfo($oldName, PATHINFO_EXTENSION));

    // Extensions autorisees.
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    // Refuse les formats non autorises.
    if (!in_array($extension, $allowedExtensions, true)) {
        return null;
    }

    // Genere un nouveau nom aleatoire pour eviter les doublons.
    $newName = bin2hex(random_bytes(8)) . '.' . $extension;

    // Chemin final de l'image.
    $destination = make_path($config['announcement_images_root'], $newName);

    // Deplace l'image dans le dossier de stockage.
    move_uploaded_file($_FILES['announcement_image']['tmp_name'], $destination);

    // Renvoie le nom sauvegarde dans l'annonce.
    return $newName;
}

function delete_announcement_image($config, $imageName)
{
    // Nettoie le nom de l'image.
    $imageName = clean_file_name($imageName);

    // Dossier racine autorise pour les images.
    $root = realpath($config['announcement_images_root']);

    // Chemin reel de l'image.
    $image = $imageName !== '' ? realpath(make_path($config['announcement_images_root'], $imageName)) : false;

    // Supprime seulement si l'image est bien dans le bon dossier.
    if ($root && $image && is_file($image) && is_in_folder($image, $root)) {
        unlink($image);
    }
}

function clean_path($path)
{
    // Remplace les slash Windows par des slash web, puis retire les slash autour.
    $path = trim(str_replace('\\', '/', $path), '/');

    // Chemin vide = dossier racine.
    if ($path === '') {
        return '';
    }

    // Contiendra les morceaux de chemin nettoyes.
    $cleanParts = [];

    // Decoupe le chemin en dossiers.
    $parts = explode('/', $path);

    // Verifie chaque morceau du chemin.
    foreach ($parts as $part) {
        // Refuse les chemins dangereux comme ../
        if ($part === '' || $part === '.' || $part === '..') {
            return null;
        }

        // Nettoie chaque nom de dossier.
        $cleanParts[] = clean_file_name($part);
    }

    // Recompose le chemin propre.
    return implode('/', $cleanParts);
}

function clean_file_name($name)
{
    // Remplace les caracteres non autorises par "_".
    $name = preg_replace('/[^A-Za-z0-9._ -]/', '_', $name);

    // Retire les espaces/points inutiles autour du nom.
    return trim($name ?? '', " ._\t\n\r\0\x0B");
}

function get_available_file_name($folder, $fileName)
{
    // Chemin initial voulu.
    $fullPath = $folder . DIRECTORY_SEPARATOR . $fileName;

    // Si aucun fichier avec ce nom n'existe, on peut l'utiliser.
    if (!file_exists($fullPath)) {
        return $fullPath;
    }

    // Separe le nom et l'extension.
    $info = pathinfo($fileName);
    $name = $info['filename'];
    $extension = isset($info['extension']) ? '.' . $info['extension'] : '';

    // Compteur pour ajouter -2, -3, etc.
    $number = 2;

    // Cherche le prochain nom disponible.
    while (file_exists($folder . DIRECTORY_SEPARATOR . $name . '-' . $number . $extension)) {
        $number++;
    }

    // Renvoie le nom disponible trouve.
    return $folder . DIRECTORY_SEPARATOR . $name . '-' . $number . $extension;
}

function remove_empty_folders($folder, $root)
{
    // Remonte les dossiers vides jusqu'au dossier racine.
    while ($folder !== $root && is_in_folder($folder, $root)) {
        // Liste le contenu du dossier.
        $items = scandir($folder);

        // Retire . et ..
        $items = array_diff($items, ['.', '..']);

        // S'il reste quelque chose, on s'arrete.
        if (!empty($items)) {
            break;
        }

        // Supprime le dossier vide.
        rmdir($folder);

        // Passe au dossier parent.
        $folder = dirname($folder);
    }
}

function make_path($folder, $path)
{
    // Si aucun sous-chemin, on renvoie le dossier de base.
    if ($path === '') {
        return $folder;
    }

    // Assemble un dossier racine avec un chemin relatif.
    return rtrim($folder, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $path);
}

function is_in_folder($path, $folder)
{
    // Normalise les slashs pour comparer correctement.
    $path = rtrim(str_replace('\\', '/', $path), '/');
    $folder = rtrim(str_replace('\\', '/', $folder), '/');

    // Vrai si le chemin est le dossier lui-meme ou un element dedans.
    return $path === $folder || strpos($path . '/', $folder . '/') === 0;
}

function format_size($bytes)
{
    // Affiche en Mo si assez grand.
    if ($bytes >= 1048576) {
        return round($bytes / 1048576, 1) . ' Mo';
    }

    // Affiche en Ko si assez grand.
    if ($bytes >= 1024) {
        return round($bytes / 1024, 1) . ' Ko';
    }

    // Sinon affiche en octets.
    return $bytes . ' o';
}

function pop_flash()
{
    // S'il n'y a pas de message temporaire, on renvoie null.
    if (empty($_SESSION['flash'])) {
        return null;
    }

    // Recupere le message.
    $message = $_SESSION['flash'];

    // Supprime le message pour qu'il ne s'affiche qu'une fois.
    unset($_SESSION['flash']);

    // Renvoie le message.
    return $message;
}

function redirect($page)
{
    // Redirection HTTP.
    header('Location: ' . $page);

    // Stoppe le script apres la redirection.
    exit;
}

function e($text)
{
    // Protege l'affichage HTML contre les caracteres dangereux.
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

function render_unread_badge($count)
{
    // Si aucun message non lu, on n'affiche rien.
    if ($count <= 0) {
        return '';
    }

    // Si trop de messages, on affiche 9+.
    if ($count > 9) {
        return '<span class="unread-badge">9+</span>';
    }

    // Sinon on affiche le nombre exact.
    return '<span class="unread-badge">' . $count . '</span>';
}

function notification_data($config, $currentUser)
{
    // Donnees envoyees au JavaScript pour creer les notifications navigateur.
    $announcements = [];

    // Prepare les annonces a surveiller.
    foreach (load_announcements($config) as $announcement) {
        // Chaque annonce garde son id, son titre et son contenu pour la notification.
        $announcements[] = [
            'id' => $announcement['id'] ?? '',
            'title' => $announcement['title'] ?? 'Nouvelle annonce',
            'content' => $announcement['content'] ?? '',
        ];
    }

    $messages = [];

    // Prepare les messages a surveiller.
    foreach (user_conversations($config, $currentUser) as $conversation) {
        // Parcourt tous les messages de chaque conversation de l'utilisateur.
        foreach ($conversation['messages'] ?? [] as $position => $message) {
            // On ne notifie pas ses propres messages.
            if (($message['author'] ?? '') !== $currentUser) {
                $messages[] = [
                    // ID unique du message pour ne pas notifier deux fois.
                    'id' => ($conversation['id'] ?? '') . '-' . $position . '-' . ($message['time'] ?? ''),
                    // Conversation a ouvrir quand on clique sur la notification.
                    'conversation_id' => $conversation['id'] ?? '',
                    // Auteur du message.
                    'author' => $message['author'] ?? '',
                    // Contenu du message.
                    'text' => $message['text'] ?? '',
                ];
            }
        }
    }

    // Renvoie les annonces et messages sous forme de tableau.
    return [
        'announcements' => $announcements,
        'messages' => $messages,
    ];
}

function render_browser_notifications_script($config, $currentUser)
{
    // Convertit les annonces/messages en JSON pour JavaScript.
    $json = json_encode(notification_data($config, $currentUser), JSON_UNESCAPED_UNICODE);

    // Convertit le chemin du logo en JSON pour l'utiliser comme icone.
    $logo = json_encode($config['notifs_path'], JSON_UNESCAPED_UNICODE);

    // Adresse du dossier actuel, pour creer des liens absolus dans les notifications.
    // Exemple : si le site est sur http://localhost/app/index.php, dirname vaut /app.
    $baseUrl = json_encode(rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\'), JSON_UNESCAPED_UNICODE);

    // Heredoc = grand bloc de texte plus facile a lire qu'une chaine avec plein de guillemets.
    return <<<HTML
<script>
    (function () {
        // Verifie si le navigateur supporte les notifications.
        if (!("Notification" in window)) {
            return;
        }

        // Si l'utilisateur n'a pas accepte les notifications, on ne peut rien afficher.
        if (Notification.permission !== "granted") {
            return;
        }

        // Donnees preparees par PHP puis utilisees en JavaScript.
        var data = $json;
        var logo = $logo;
        var baseUrl = $baseUrl;

        // Construit une URL complete pour eviter d'ouvrir seulement http://localhost.
        function siteUrl(path) {
            return window.location.origin + baseUrl + "/" + path;
        }

        // Listes deja vues, gardees dans le navigateur de l'utilisateur.
        var knownAnnouncements = JSON.parse(localStorage.getItem("knownAnnouncements") || "null");
        var knownMessages = JSON.parse(localStorage.getItem("knownMessages") || "null");

        // Raccourcit le texte dans les notifications.
        function cleanText(text, maxLength) {
            text = String(text || "").replace(/\\s+/g, " ").trim();

            if (text.length > maxLength) {
                return text.substring(0, maxLength - 1) + "...";
            }

            return text;
        }

        // Au premier chargement, on memorise l'existant sans envoyer de notification.
        if (knownAnnouncements === null) {
            knownAnnouncements = data.announcements.map(function (item) {
                return item.id;
            });
            localStorage.setItem("knownAnnouncements", JSON.stringify(knownAnnouncements));
        }

        if (knownMessages === null) {
            knownMessages = data.messages.map(function (item) {
                return item.id;
            });
            localStorage.setItem("knownMessages", JSON.stringify(knownMessages));
        }

        // Notifications pour les nouvelles annonces.
        data.announcements.forEach(function (announcement) {
            if (knownAnnouncements.indexOf(announcement.id) === -1) {
                var notification = new Notification("⚠️Intranet - " + announcement.title, {
                    body: cleanText(announcement.content + "...", 8),
                    icon: logo,
                    badge: logo,
                    tag: "announcement-" + announcement.id,
                    renotify: true
                });

                notification.onclick = function () {
                    window.focus();
                    window.location.href = siteUrl("index.php#announcement-" + encodeURIComponent(announcement.id));
                };

                knownAnnouncements.push(announcement.id);
            }
        });

        // Notifications pour les nouveaux messages recus.
        data.messages.forEach(function (message) {
            if (knownMessages.indexOf(message.id) === -1) {
                var notification = new Notification("⚠️Intranet - Message de " + message.author, {
                    body: cleanText(message.text + "...", 8),
                    icon: logo,
                    badge: logo,
                    tag: "message-" + message.id,
                    renotify: true
                });

                notification.onclick = function () {
                    window.focus();
                    window.location.href = siteUrl("chat.php?from_notification=1&conversation=" + encodeURIComponent(message.conversation_id));
                };

                knownMessages.push(message.id);
            }
        });

        // Sauvegarde les elements deja notifies pour eviter les doublons.
        localStorage.setItem("knownAnnouncements", JSON.stringify(knownAnnouncements));
        localStorage.setItem("knownMessages", JSON.stringify(knownMessages));
    })();
</script>
HTML;
}
