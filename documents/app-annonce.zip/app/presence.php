<?php

// Ce fichier est appele automatiquement en JavaScript.
// Il sert juste a dire que l'utilisateur est encore actif.
require __DIR__ . '/functions.php';

// Demarre la session et charge la configuration.
$config = app_boot();

// Recupere l'identifiant si l'utilisateur est connecte.
$identifier = current_user_identifier();

if ($identifier !== null) {
    // Met a jour la derniere activite de l'utilisateur.
    mark_user_online($config, $identifier);
}

// Renvoie une petite reponse JSON au navigateur.
header('Content-Type: application/json');
echo json_encode(['ok' => true]);
