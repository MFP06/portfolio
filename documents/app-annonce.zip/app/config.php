<?php

// En PHP, ce fichier renvoie un tableau de configuration.
// Dans un tableau, le symbole => veut dire "la cle a gauche correspond a la valeur a droite".
return [
    // Ajoutez ici les IP autorisees a acceder a l'administration.
    'admin_ips' => [
        '127.0.0.1',
    ],

    // Chemin web du logo affiche sur la page de connexion et dans le menu.
    // Le fichier doit donc etre place dans le dossier image du projet.
    'logo_path' => 'image/logo.jpg',

    'notifs_path' => 'image/notifs2.png',

    // Dossier ou sont stockees les donnees JSON a la place d'une vraie base de donnees.
    'data_dir' => __DIR__ . '/storage/data',

    // Dossier ou sont stockes les fichiers ajoutes par admin.
    'files_root' => __DIR__ . '/storage/files',

    // Dossier ou sont stockees les images ajoutees aux annonces.
    'announcement_images_root' => __DIR__ . '/storage/announcement-images',

    // Fichier JSON qui stocke les conversations et messages du chat.
    'chat_file' => __DIR__ . '/storage/data/chat.json',

    // Fichier de logs des messages.
    // Format JSONL : une ligne JSON par message envoye.
    'chat_log_file' => __DIR__ . '/storage/data/message-logs.jsonl',

    // Fichier JSON qui stocke les utilisateurs connectes avec leur derniere activite.
    'online_file' => __DIR__ . '/storage/data/online-users.json',
];
