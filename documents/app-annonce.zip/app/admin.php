<?php

// La page admin utilise les fonctions communes : protection IP, annonces, fichiers et notifications.
require __DIR__ . '/functions.php';

// app_boot() demarre la session, lit config.php et prepare les fichiers JSON.
$config = app_boot();

// Si l'IP du visiteur n'est pas dans config.php, require_admin() affiche "Acces refuse" et arrete la page.
// Cela empeche un utilisateur normal d'ouvrir admin.php directement dans l'URL.
require_admin($config);

// On recupere l'identifiant de l'utilisateur connecte.
// Si personne n'est connecte, require_login() renvoie automatiquement vers index.php.
$userIdentifier = require_login();

// On garde l'utilisateur visible comme connecte pendant qu'il est sur la page admin.
mark_user_online($config, $userIdentifier);

// Si un formulaire admin est envoye, on traite l'action demandee.
$action = $_POST['action'] ?? null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Selon le champ cache "action" envoye par le formulaire, on appelle la bonne fonction.
    // Exemple : le formulaire d'annonce envoie action=add_announcement.
    if ($action === 'add_announcement') {
        // Ajoute une annonce dans le fichier JSON et enregistre l'image si une image a ete envoyee.
        add_announcement($config);
    }

    if ($action === 'delete_announcement') {
        // Supprime une annonce precise grace a son id cache dans le formulaire.
        delete_announcement($config);
    }

    if ($action === 'upload_file') {
        // Ajoute le fichier envoye dans le dossier demande par l'admin.
        upload_file($config);
    }

    if ($action === 'delete_file') {
        // Supprime le fichier choisi dans l'arborescence admin.
        delete_file($config);
    }
}

// A partir d'ici, on prepare les donnees utilisees plus bas dans le HTML admin.
$announcements = load_announcements($config);
$files = scan_files($config['files_root']);
$unreadMessages = unread_count_total($config, $userIdentifier);
$flash = pop_flash();

// Compte les fichiers de l'arborescence pour afficher le compteur en haut de la page.
// On utilise une liste temporaire $foldersToCount pour parcourir aussi les sous-dossiers.
$fileCount = 0;
$foldersToCount = $files;
while ($foldersToCount) {
    // array_shift() prend le premier element de la liste et le retire de la liste.
    $item = array_shift($foldersToCount);

    if ($item['type'] === 'file') {
        $fileCount++;
    }

    if ($item['type'] === 'dir') {
        // Si c'est un dossier, on ajoute ses enfants dans la liste pour les compter ensuite.
        foreach ($item['children'] as $child) {
            $foldersToCount[] = $child;
        }
    }
}

?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Administration intranet</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="topbar">
        <a class="brand" href="index.php">
            <img src="<?= e($config['logo_path']) ?>" alt="Logo">
            <span>Intranet</span>
        </a>
        <nav class="top-actions">
            <span class="user-pill"><?= e($userIdentifier) ?></span>
            <a class="nav-button" href="index.php">Accueil</a>
            <a class="nav-button chat-button" href="chat.php">
                Chat
                <?php if ($unreadMessages > 0): ?>
                    <span class="unread-badge"><?= $unreadMessages > 9 ? '9+' : e((string)$unreadMessages) ?></span>
                <?php endif; ?>
            </a>
            <a class="nav-button logout" href="index.php?action=logout">Se deconnecter</a>
        </nav>
    </header>

    <main class="page admin-page">
        <?php if ($flash): ?>
            <p class="flash flash-main"><?= e($flash) ?></p>
        <?php endif; ?>

        <section class="admin-header">
            <div>
                <p class="eyebrow">Administration</p>
                <h1>Gestion du contenu</h1>
            </div>
            <div class="admin-metrics">
                <!-- Petits compteurs rapides dans l'administration. -->
                <span><?= count($announcements) ?> annonces</span>
                <span><?= $fileCount ?> fichiers</span>
                <span>IP <?= e(get_visitor_ip()) ?></span>
            </div>
        </section>

        <section class="admin-workbench">
            <!-- Formulaire pour publier une annonce. -->
            <form method="post" enctype="multipart/form-data" class="section admin-form featured-form">
                <!-- Champ cache : dit a PHP qu'il faut ajouter une annonce. -->
                <input type="hidden" name="action" value="add_announcement">
                <div class="section-head">
                    <div>
                        <p class="eyebrow">Publication</p>
                        <h2>Nouvelle annonce</h2>
                    </div>
                </div>
                <label for="title">Titre</label>
                <input id="title" name="title" type="text" required>
                <label for="content">Message</label>
                <textarea id="content" name="content" rows="7" required></textarea>
                <label for="announcement_image">Image optionnelle</label>
                <input id="announcement_image" name="announcement_image" type="file" accept="image/png,image/jpeg,image/gif,image/webp">
                <button type="submit">Publier</button>
            </form>

            <!-- Formulaire pour ajouter un fichier dans un dossier. -->
            <form method="post" enctype="multipart/form-data" class="section admin-form side-form">
                <!-- Champ cache : dit a PHP qu'il faut envoyer un fichier. -->
                <input type="hidden" name="action" value="upload_file">
                <div class="section-head">
                    <div>
                        <p class="eyebrow">Documents</p>
                        <h2>Ajouter un fichier</h2>
                    </div>
                </div>
                <label for="folder">Dossier cible</label>
                <input id="folder" name="folder" type="text" placeholder="ex: rh/documents">
                <label for="file">Fichier</label>
                <input id="file" name="file" type="file" required>
                <button type="submit">Envoyer</button>
            </form>
        </section>

        <section class="section">
            <div class="section-head">
                <div>
                    <p class="eyebrow">Moderation</p>
                    <h2>Annonces existantes</h2>
                </div>
            </div>

            <?php if (!$announcements): ?>
                <!-- Message si aucune annonce n'existe. -->
                <p class="empty">Aucune annonce a supprimer.</p>
            <?php endif; ?>

            <div class="admin-list">
                <!-- Liste des annonces avec bouton supprimer. -->
                <?php foreach ($announcements as $announcement): ?>
                    <form method="post" class="delete-row">
                        <!-- Action demandee a PHP : suppression d'une annonce. -->
                        <input type="hidden" name="action" value="delete_announcement">
                        <!-- ID exact de l'annonce a supprimer. -->
                        <input type="hidden" name="id" value="<?= e($announcement['id'] ?? '') ?>">
                        <span>
                            <strong><?= e($announcement['title'] ?? '') ?></strong>
                            <small><?= e($announcement['created_at'] ?? '') ?><?= !empty($announcement['image']) ? ' - image jointe' : '' ?></small>
                        </span>
                        <button type="submit">Supprimer</button>
                    </form>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="section">
            <div class="section-head">
                <div>
                    <p class="eyebrow">Gestion</p>
                    <h2>Fichiers publies</h2>
                </div>
            </div>

            <?php if (!$files): ?>
                <!-- Message si aucun fichier n'existe. -->
                <p class="empty">Aucun fichier disponible.</p>
            <?php else: ?>
                <!-- Arborescence admin avec boutons supprimer. -->
                <div class="file-tree">
                    <?= render_file_tree($files, true) ?>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <?= render_browser_notifications_script($config, $userIdentifier) ?>

    <script>
        // Sauvegarde les dossiers ouverts dans l'arborescence.
        function saveOpenFolders() {
            var openFolders = [];
            document.querySelectorAll('details[data-tree-path]').forEach(function (detail) {
                if (detail.open) {
                    // On garde le chemin du dossier ouvert pour le retrouver apres reload.
                    openFolders.push(detail.dataset.treePath);
                }
            });
            localStorage.setItem('openFileTree', JSON.stringify(openFolders));
        }

        // Restaure les dossiers ouverts apres rechargement.
        function restoreOpenFolders() {
            var openFolders = JSON.parse(localStorage.getItem('openFileTree') || '[]');
            document.querySelectorAll('details[data-tree-path]').forEach(function (detail) {
                if (openFolders.indexOf(detail.dataset.treePath) !== -1) {
                    // Rouvre uniquement les dossiers ouverts par l'utilisateur.
                    detail.open = true;
                }
                // Sauvegarde automatiquement a chaque changement.
                detail.addEventListener('toggle', saveOpenFolders);
            });
        }

        // Lance la restauration au chargement de la page.
        restoreOpenFolders();

        // Ping regulier pour garder l'utilisateur en ligne.
        setInterval(function () {
            fetch('presence.php', { cache: 'no-store' });
        }, 10000);

        // Recharge l'admin pour garder les notifications chat a jour.
        setInterval(function () {
            var active = document.activeElement;
            var isWriting = active && (active.tagName === 'TEXTAREA' || active.tagName === 'INPUT');

            // Ne recharge pas pendant une saisie de formulaire.
            if (!isWriting) {
                window.location.reload();
            }
        }, 15000);
    </script>
</body>
</html>
