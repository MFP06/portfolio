<?php

// La page a besoin de functions.php car ce fichier contient les fonctions communes du site :
// connexion, deconnexion, chargement des annonces, gestion des fichiers, chat et notifications.
require __DIR__ . '/functions.php';

// app_boot() demarre la session PHP, lit config.php et verifie que les dossiers/fichiers JSON existent.
// La variable $config contient ensuite les chemins importants et les adresses IP admin.
$config = app_boot();

// Si un formulaire envoie un champ "action" en POST, on prend cette valeur.
// Sinon, si l'URL contient une action en GET comme ?action=logout, on prend cette valeur.
// Sinon, aucune action n'est demandee et $action vaut null.
$action = $_POST['action'] ?? $_GET['action'] ?? null;

// Si le formulaire de connexion est rempli et envoye en POST, on connecte l'utilisateur.
// Le POST est important ici : cela evite de se connecter juste avec une URL du type ?action=login.
if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    // Dans functions.php, handle_login() recupere l'identifiant, verifie la longueur minimum,
    // verifie que le meme identifiant n'est pas deja connecte, cree la session,
    // marque l'utilisateur comme connecte et redirige vers l'accueil.
    handle_login();
}

// Si l'utilisateur clique sur deconnexion, ou ajoute ?action=logout dans l'URL, on le deconnecte.
if ($action === 'logout') {
    // Dans functions.php, logout() retire l'utilisateur des connectes,
    // supprime ses conversations temporaires et renvoie vers la page de connexion.
    logout();
}

// On verifie si un utilisateur est deja connecte sur ce navigateur.
// current_user_identifier() regarde dans la session PHP si un identifiant existe deja.
$userIdentifier = current_user_identifier();

// Si personne n'est connecte, on affiche directement la page de connexion.
if ($userIdentifier === null) {
    // Recupere un message d'erreur temporaire, par exemple "Cet identifiant est deja connecte".
    // pop_flash() supprime aussi le message pour qu'il ne s'affiche qu'une seule fois.
    $flash = pop_flash();
    ?>
    <!doctype html>
    <html lang="fr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Connexion intranet</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body class="login-page">
        <main class="login-shell" aria-label="Connexion">
            <section class="login-panel">
                <form method="post" class="login-form" id="loginForm">
                    <img class="login-logo" src="<?= e($config['logo_path']) ?>" alt="Logo">
                    <div class="login-copy">
                        <p class="eyebrow">Intranet prive</p>
                        <h1>Connexion</h1>
                        <p>Acces aux annonces et documents internes.</p>
                    </div>

                    <!-- Ce champ cache envoie action=login en POST quand on clique sur Entrer. -->
                    <input type="hidden" name="action" value="login">
                    <!-- minlength=6 oblige l'utilisateur a mettre au moins 6 caracteres avant l'envoi. -->
                    <input id="identifier" name="identifier" type="text" autocomplete="username" minlength="6" required autofocus placeholder="Votre identifiant">

                    <button type="submit">Entrer</button>

                    <?php if ($flash): ?>
                        <!-- Affiche le message temporaire recupere plus haut, seulement s'il existe. -->
                        <p class="flash"><?= e($flash) ?></p>
                    <?php endif; ?>
                </form>
            </section>
        </main>

        <script>
            // Au clic sur Connexion, on demande aussi l'autorisation des notifications.
            document.getElementById('loginForm').addEventListener('submit', function (event) {
                var form = this;

                // Si le navigateur ne sait pas faire de notifications, on ne bloque pas la connexion.
                // Si l'utilisateur a deja accepte ou refuse, on ne redemande pas l'autorisation.
                // form.dataset.ready evite une boucle infinie quand on relance form.submit().
                if (!('Notification' in window) || Notification.permission !== 'default' || form.dataset.ready === '1') {
                    return;
                }

                // On bloque temporairement l'envoi du formulaire pour afficher la demande du navigateur.
                event.preventDefault();
                Notification.requestPermission().then(function () {
                    // Ce marqueur indique que la demande a deja ete faite et que le formulaire peut partir.
                    form.dataset.ready = '1';
                    form.submit();
                });
            });
        </script>
    </body>
    </html>
    <?php
    exit;
}

// A partir d'ici, l'utilisateur est connecte.
// On met a jour son heure d'activite pour qu'il apparaisse comme "connecte" dans le chat.
mark_user_online($config, $userIdentifier);

// Si l'URL demande un telechargement, exemple index.php?action=download&file=document.pdf,
// on lance la fonction de telechargement securise, puis le script s'arrete dans cette fonction.
if ($action === 'download') {
    serve_download($config);
}

// Si l'URL demande une image d'annonce, PHP va chercher l'image dans le dossier autorise.
// Cela permet d'afficher les images sans donner un acces direct trop large au serveur.
if ($action === 'announcement_image') {
    serve_announcement_image($config);
}

// A partir d'ici, on prepare les donnees utilisees plus bas dans le HTML de l'accueil.
// Comme les variables sont preparees ici, le HTML reste plus simple a comprendre ensuite.
$isAdmin = is_admin_ip($config['admin_ips']);
$announcements = load_announcements($config);
$files = scan_files($config['files_root']);
$unreadMessages = unread_count_total($config, $userIdentifier);
$flash = pop_flash();

?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Intranet</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="topbar">
        <a class="brand" href="index.php">
            <img src="<?= e($config['logo_path']) ?>" alt="Logo">
            <span>Intranet</span>
        </a>
        <nav class="top-actions">
            <span class="user-pill"><?= e($userIdentifier) ?></span>
            <?php if ($isAdmin): ?>
                <!-- Le bouton Administration s'affiche uniquement si l'adresse IP est autorisee dans config.php. -->
                <a class="nav-button" href="admin.php">Administration</a>
            <?php endif; ?>
            <a class="nav-button chat-button" href="chat.php">
                Chat
                <?php if ($unreadMessages > 0): ?>
                    <!-- Badge rouge affiche seulement s'il y a au moins un message non lu. -->
                    <span class="unread-badge"><?= $unreadMessages > 9 ? '9+' : e((string)$unreadMessages) ?></span>
                <?php endif; ?>
            </a>
            <a class="nav-button logout" href="?action=logout">Se deconnecter</a>
        </nav>
    </header>

    <main class="page">
        <?php if ($flash): ?>
            <!-- Message temporaire affiche apres une action, par exemple une erreur ou une confirmation. -->
            <p class="flash flash-main"><?= e($flash) ?></p>
        <?php endif; ?>

        <section class="section announcements">
            <div class="section-head">
                <div>
                    <p class="eyebrow">A la une</p>
                    <h2>Annonces</h2>
                </div>
            </div>

            <?php if (!$announcements): ?>
                <!-- Message affiche s'il n'y a aucune annonce dans le fichier JSON. -->
                <p class="empty">Aucune annonce pour le moment.</p>
            <?php endif; ?>

            <div class="announcement-list">
                <?php foreach ($announcements as $announcement): ?>
                    <!-- L'id permet a une notification d'ouvrir directement cette annonce avec #announcement-id. -->
                    <article class="announcement" id="announcement-<?= e($announcement['id'] ?? '') ?>">
                        <?php if (!empty($announcement['image'])): ?>
                            <!-- L'image passe par PHP pour verifier que le fichier demande est bien autorise. -->
                            <img class="announcement-image" src="index.php?action=announcement_image&image=<?= e($announcement['image']) ?>" alt="">
                        <?php endif; ?>
                        <time><?= e($announcement['created_at'] ?? '') ?></time>
                        <h3><?= e($announcement['title'] ?? '') ?></h3>
                        <p><?= nl2br(e($announcement['content'] ?? '')) ?></p>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="section">
            <div class="section-head">
                <div>
                    <p class="eyebrow">Documents</p>
                    <h2>Fichiers disponibles</h2>
                </div>
            </div>

            <?php if (!$files): ?>
                <!-- Message affiche si le dossier storage/files ne contient aucun fichier affichable. -->
                <p class="empty">Aucun fichier disponible.</p>
            <?php else: ?>
                <!-- render_file_tree() transforme le tableau des fichiers en vraie arborescence HTML. -->
                <div class="file-tree">
                    <?= render_file_tree($files, false) ?>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <!-- Script commun qui affiche les notifications navigateur pour annonces et messages. -->
    <?= render_browser_notifications_script($config, $userIdentifier) ?>

    <script>
        // Sauvegarde les dossiers ouverts dans l'arborescence.
        function saveOpenFolders() {
            var openFolders = [];
            document.querySelectorAll('details[data-tree-path]').forEach(function (detail) {
                if (detail.open) {
                    // On garde le chemin du dossier ouvert, pas son titre affiche.
                    openFolders.push(detail.dataset.treePath);
                }
            });
            localStorage.setItem('openFileTree', JSON.stringify(openFolders));
        }

        // Restaure les dossiers ouverts apres un rechargement de page.
        function restoreOpenFolders() {
            var openFolders = JSON.parse(localStorage.getItem('openFileTree') || '[]');
            document.querySelectorAll('details[data-tree-path]').forEach(function (detail) {
                if (openFolders.indexOf(detail.dataset.treePath) !== -1) {
                    // Si ce dossier etait ouvert avant le rechargement, on le rouvre.
                    detail.open = true;
                }
                // A chaque ouverture/fermeture de dossier, on sauvegarde le nouvel etat.
                detail.addEventListener('toggle', saveOpenFolders);
            });
        }

        // Lance la restauration au chargement.
        restoreOpenFolders();

        // Envoie regulierement un signal a presence.php pour dire que l'utilisateur est encore connecte.
        setInterval(function () {
            fetch('presence.php', { cache: 'no-store' });
        }, 10000);

        // Recharge l'accueil pour mettre a jour les badges chat et les notifications.
        setInterval(function () {
            var active = document.activeElement;
            var isWriting = active && (active.tagName === 'TEXTAREA' || active.tagName === 'INPUT');

            // Ne recharge pas si l'utilisateur est en train d'ecrire dans un champ.
            if (!isWriting) {
                window.location.reload();
            }
        }, 7000);
    </script>
</body>
</html>
